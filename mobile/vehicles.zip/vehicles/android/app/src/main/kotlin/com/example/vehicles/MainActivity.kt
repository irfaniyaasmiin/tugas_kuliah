package com.example.vehicles

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
