import 'package:flutter/material.dart';
import 'package:kuis/daftar_barang_dummy.dart';
import 'package:kuis/login_page.dart'; // Pastikan halaman login diimpor

class MarketPage extends StatelessWidget {
  final String username;

  const MarketPage({super.key, required this.username});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Home Page"),
        backgroundColor: Colors.blue[200],
      ),
      
      body: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
        ),
        itemCount: supermarketItemList.length,
        itemBuilder: (context, index) {
          SupermarketItem market = supermarketItemList[index];
          return Card(
            child: Column(
              children: [
                //Menampilkan array
                Padding(padding: EdgeInsets.all(20)),
                Image.network(
                  market.imageUrls[0],
                  width: 100, 
                  height: 100, 
                  fit: BoxFit.fill),
                Text(market.name),
                Text(market.price),
                Text("Stock: -"),
                // Text(market.stock)
              ],
            ),
          );
        },
      ),

      // FloatingActionButton untuk Logout
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Navigasi kembali ke halaman LoginPage
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => LoginPage()),
          );
        },
        child: Icon(Icons.logout),
        backgroundColor: Colors.red, // Warna merah untuk logout
        tooltip: 'Logout',
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }
}
